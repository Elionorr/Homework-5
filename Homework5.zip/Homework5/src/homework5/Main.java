package homework5;

import rectsChild.Square;

public class Main {

	public static void main(String[] args) {
		
		System.out.println("Areas and Perimeters of Rectangles: ");
		Rectangle rectangle1 = new Rectangle(50, 70);
		Rectangle rectangle2 = new Rectangle();
		
		System.out.println("Area: " + rectangle1.computeArea()); // computeArea(double width, double height)
		System.out.println("Perimeter: " + rectangle1.computePerimeter()); // computePerimeter(double width, double height)
		System.out.println("Area: " + rectangle2.computeArea()); // computeArea()
		System.out.println("Perimeter: " + rectangle2.computePerimeter() + "\n"); // computePerimeter()

		System.out.println("Area's and Perimeter's from Figure: ");
		Figure figure = new Figure("ABC");	
		System.out.println("Area: " + figure.computeArea());
		System.out.println("Perimeter: " + figure.computePerimeter() + "\n");
			
		System.out.println("Area's and Perimeter's from Square: ");
		Square square = new Square(7);
		System.out.println("Area: " + square.computeArea());
		System.out.println("Perimeter: " + square.computePerimeter() + "\n");
		
		
		System.out.println("Examples of instanceof: ");
		System.out.println(rectangle1 instanceof Figure);
		System.out.println(rectangle2 instanceof Rectangle);
		System.out.println(figure instanceof Rectangle);
		System.out.println(figure instanceof Figure);
	}

}
