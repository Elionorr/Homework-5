package homework5;


public class Rectangle extends Figure{
	private double height;
	private double width;
	private static int maxHeight;
	private static int maxWidth;

	 	static{
	        maxWidth = 20;
	        maxHeight = 40;
	    }
	 
	public Rectangle(double width, double height) {
			super("ABC");
			if(width <= maxWidth) {
				this.width = width;
			}else {
				this.width = maxWidth;
			}
			if(height <= maxHeight) {
				this.height = height;
			}else {
				this.height = maxHeight;
			}
	    }
	
	protected double computeArea(double width, double height) {
		return this.width * this.height;
	}
	
	protected double computePerimeter(double width, double height) {
		return (this.width + this.height)*2;
	}
	
	
	public Rectangle() {
		super("ABC");
        width = 4;
        height = 3;
    }

	protected double computeArea() {
		return width * height;
	}
	
	protected double computePerimeter() {
		return (width + height)*2;
	}
	
}
