package homework5;

public class Figure {
	
	public Figure(String string) {
		System.out.println(string);
	}

	double computeArea() {
		return 1;
	}
	
	double computePerimeter() {
		return -1;
	}
	
	public final static void sayHello() {
		System.out.println("Hello! :)");
	}
}
