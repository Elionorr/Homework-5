package rectsChild;

import homework5.Rectangle;

	public final class Square extends Rectangle {
	
		private double sq;
		 public Square(double sq) {
		        this.sq = sq;
		    }
		
		public double computeArea() {
			return super.computeArea(sq, sq);
		}
		
		public double computePerimeter() {
			return super.computePerimeter(sq, sq);
		}	
	
	}
